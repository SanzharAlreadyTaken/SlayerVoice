cmake_minimum_required(VERSION 3.22.1)
project(slayervoice CXX)

find_package(oboe REQUIRED CONFIG)

add_library(slayervoice SHARED voice_engine.cpp)
target_compile_options(slayervoice PRIVATE -O3 -ffast-math -Wall)
target_link_libraries(slayervoice oboe::oboe log)
