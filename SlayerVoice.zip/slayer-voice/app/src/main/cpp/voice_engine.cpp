// Slayer Voice — аудиодвижок: микрофон -> VoiceDSP -> выход, с минимальной задержкой (Oboe/AAudio).
#include <jni.h>
#include <oboe/Oboe.h>
#include <android/log.h>
#include <algorithm>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "dsp.h"

#define LOG_TAG "SlayerVoice"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

class Engine : public oboe::AudioStreamDataCallback, public oboe::AudioStreamErrorCallback {
public:
    VoiceDSP dsp;

    Engine() : inBuf(16384, 0.f) {}

    bool start() {
        std::lock_guard<std::mutex> lock(mtx);
        if (output) return true;
        wanted = true;
        bool ok = openLocked();
        if (!ok) wanted = false;
        return ok;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mtx);
        wanted = false;
        closeLocked();
    }

    std::string info() {
        std::lock_guard<std::mutex> lock(mtx);
        if (!output || !input) return lastError.empty() ? "Выключено" : lastError;
        double outLat = 0, inLat = 0;
        auto lo = output->calculateLatencyMillis();
        if (lo) outLat = lo.value();
        auto li = input->calculateLatencyMillis();
        if (li) inLat = li.value();
        char s[256];
        snprintf(s, sizeof(s),
                 "Работает • %d Гц • задержка ≈ %.0f мс\nвыход: %s, вход: %s, пачка %d",
                 output->getSampleRate(), outLat + inLat,
                 output->getSharingMode() == oboe::SharingMode::Exclusive ? "эксклюзивный" : "общий",
                 input->getSharingMode() == oboe::SharingMode::Exclusive ? "эксклюзивный" : "общий",
                 output->getFramesPerBurst());
        return s;
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *, void *audioData, int32_t numFrames) override {
        auto *out = static_cast<float *>(audioData);
        int n = std::min<int>(numFrames, (int) inBuf.size());
        int got = 0;
        if (input) {
            // Не даём задержке накапливаться: лишнее из входа выбрасываем.
            auto avail = input->getAvailableFrames();
            if (avail && avail.value() > n * 3) {
                int drop = avail.value() - n;
                while (drop > 0) {
                    int c = std::min<int>(drop, (int) inBuf.size());
                    auto r = input->read(inBuf.data(), c, 0);
                    if (!r || r.value() <= 0) break;
                    drop -= r.value();
                }
            }
            auto r = input->read(inBuf.data(), n, 0);
            if (r) got = r.value();
        }
        for (int i = got; i < n; ++i) inBuf[i] = 0.f;
        dsp.process(inBuf.data(), out, n);
        for (int i = n; i < numFrames; ++i) out[i] = 0.f;
        return oboe::DataCallbackResult::Continue;
    }

    // Например, подключили/отключили наушники или колонку — переоткрываем потоки.
    void onErrorAfterClose(oboe::AudioStream *, oboe::Result error) override {
        LOGI("stream closed: %s, restarting", oboe::convertToText(error));
        std::thread([this] {
            std::lock_guard<std::mutex> lock(mtx);
            if (!wanted) return;
            closeLocked();
            if (!openLocked()) wanted = false;
        }).detach();
    }

private:
    std::mutex mtx;
    std::shared_ptr<oboe::AudioStream> output, input;
    std::vector<float> inBuf;
    bool wanted = false;
    std::string lastError;

    bool openLocked() {
        lastError.clear();
        oboe::AudioStreamBuilder ob;
        ob.setDirection(oboe::Direction::Output)
                ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                ->setSharingMode(oboe::SharingMode::Exclusive)
                ->setFormat(oboe::AudioFormat::Float)
                ->setChannelCount(oboe::ChannelCount::Mono)
                ->setUsage(oboe::Usage::Media)
                ->setContentType(oboe::ContentType::Speech)
                ->setFormatConversionAllowed(true)
                ->setChannelConversionAllowed(true)
                ->setDataCallback(this)
                ->setErrorCallback(this);
        auto r = ob.openStream(output);
        if (r != oboe::Result::OK) {
            lastError = std::string("Ошибка выхода: ") + oboe::convertToText(r);
            LOGE("%s", lastError.c_str());
            output.reset();
            return false;
        }
        int sr = output->getSampleRate();
        dsp.setSampleRate((float) sr);

        oboe::AudioStreamBuilder ib;
        ib.setDirection(oboe::Direction::Input)
                ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                ->setSharingMode(oboe::SharingMode::Exclusive)
                ->setFormat(oboe::AudioFormat::Float)
                ->setChannelCount(oboe::ChannelCount::Mono)
                ->setSampleRate(sr)
                ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
                ->setFormatConversionAllowed(true)
                ->setChannelConversionAllowed(true)
                ->setInputPreset(oboe::InputPreset::VoicePerformance);
        r = ib.openStream(input);
        if (r != oboe::Result::OK) {
            ib.setInputPreset(oboe::InputPreset::VoiceRecognition);
            r = ib.openStream(input);
        }
        if (r != oboe::Result::OK) {
            lastError = std::string("Ошибка микрофона: ") + oboe::convertToText(r);
            LOGE("%s", lastError.c_str());
            input.reset();
            output->close();
            output.reset();
            return false;
        }

        output->setBufferSizeInFrames(output->getFramesPerBurst() * 2);
        input->requestStart();
        r = output->requestStart();
        if (r != oboe::Result::OK) {
            lastError = std::string("Ошибка запуска: ") + oboe::convertToText(r);
            closeLocked();
            return false;
        }
        LOGI("started: sr=%d burst=%d", sr, output->getFramesPerBurst());
        return true;
    }

    void closeLocked() {
        if (output) {
            output->stop();
            output->close();
            output.reset();
        }
        if (input) {
            input->stop();
            input->close();
            input.reset();
        }
    }
};

static Engine engine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_slayer_voice_NativeEngine_start(JNIEnv *, jobject) {
    return engine.start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_slayer_voice_NativeEngine_stop(JNIEnv *, jobject) {
    engine.stop();
}

JNIEXPORT void JNICALL
Java_com_slayer_voice_NativeEngine_setParam(JNIEnv *, jobject, jint id, jfloat value) {
    if (id >= 0 && id < P_COUNT) engine.dsp.params[id].store(value);
}

JNIEXPORT jstring JNICALL
Java_com_slayer_voice_NativeEngine_info(JNIEnv *env, jobject) {
    return env->NewStringUTF(engine.info().c_str());
}

}
