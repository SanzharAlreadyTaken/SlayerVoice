// Slayer Voice — обработка голоса в реальном времени.
// Цепочка: срез низа 80 Гц -> шумодав -> понижение голоса -> «металл» -> хрип -> яркость -> громкость.
#pragma once
#include <atomic>
#include <cmath>
#include <cstring>

enum Param { P_PITCH = 0, P_METAL, P_DRIVE, P_TONE, P_GATE, P_VOLUME, P_COUNT };

class VoiceDSP {
public:
    // Все параметры 0..1, кроме PITCH (коэффициент высоты 0.5..1.5).
    std::atomic<float> params[P_COUNT];

    VoiceDSP() {
        params[P_PITCH] = 0.78f;
        params[P_METAL] = 0.15f;
        params[P_DRIVE] = 0.25f;
        params[P_TONE] = 0.60f;
        params[P_GATE] = 0.30f;
        params[P_VOLUME] = 0.70f;
        reset();
    }

    void setSampleRate(float sr) {
        fs = sr > 8000.f ? sr : 48000.f;
        reset();
    }

    void reset() {
        std::memset(buf, 0, sizeof(buf));
        w = 0;
        phase = 0.f;
        ringPh = 0.f;
        hpX = hpY = 0.f;
        lp = 0.f;
        env = 0.f;
        gateGain = 0.f;
    }

    void process(const float *in, float *out, int n) {
        const float PI = 3.14159265f;
        const float ratio = clampf(params[P_PITCH].load(), 0.4f, 1.6f);
        const float metal = clampf(params[P_METAL].load(), 0.f, 1.f);
        const float drive = clampf(params[P_DRIVE].load(), 0.f, 1.f);
        const float tone = clampf(params[P_TONE].load(), 0.f, 1.f);
        const float gate = clampf(params[P_GATE].load(), 0.f, 1.f);
        const float vol = clampf(params[P_VOLUME].load(), 0.f, 1.f);

        // Окно сдвига высоты ~40 мс, минимальная задержка 4 сэмпла.
        const float W = 0.040f * fs;
        const float minD = 4.f;
        const float dp = (1.f - ratio) / W;
        const bool bypassPitch = std::fabs(1.f - ratio) < 0.002f;

        const float hpA = 1.f / (1.f + 2.f * PI * 80.f / fs);              // ФВЧ 80 Гц
        const float thr = std::pow(10.f, (-70.f + 40.f * gate) / 20.f);      // порог шумодава -70..-30 дБ
        const float envAtt = 1.f - std::exp(-1.f / (0.002f * fs));
        const float envRel = 1.f - std::exp(-1.f / (0.120f * fs));
        const float gOpen = 1.f - std::exp(-1.f / (0.003f * fs));
        const float gClose = 1.f - std::exp(-1.f / (0.080f * fs));
        const float ringInc = 2.f * PI * 70.f / fs;                          // «металл» 70 Гц
        const float k = 1.f + drive * 8.f;
        const float kNorm = 1.f / std::sqrt(k);
        const float fc = 1000.f * std::pow(10.f, tone);                      // яркость 1..10 кГц
        const float lpA = 1.f - std::exp(-2.f * PI * fc / fs);
        const float gain = vol * 4.f;

        for (int i = 0; i < n; ++i) {
            // 1. Срез низа (гул, удары по шлему)
            float x = in[i];
            hpY = hpA * (hpY + x - hpX);
            hpX = x;
            x = hpY;

            // 2. Шумодав: глушит тишину и подавляет зацикливание звука
            float a = std::fabs(x);
            env += (a > env ? envAtt : envRel) * (a - env);
            float target = env > thr ? 1.f : 0.f;
            gateGain += (target > gateGain ? gOpen : gClose) * (target - gateGain);
            x *= gateGain;

            // 3. Сдвиг высоты: две «головки» чтения по линии задержки с плавной сменой
            buf[w] = x;
            float y;
            if (bypassPitch) {
                y = x;
            } else {
                float p2 = phase + 0.5f;
                if (p2 >= 1.f) p2 -= 1.f;
                float y1 = read(minD + phase * W);
                float y2 = read(minD + p2 * W);
                y = y1 * std::sin(PI * phase) + y2 * std::sin(PI * p2);
                phase += dp;
                if (phase >= 1.f) phase -= 1.f;
                if (phase < 0.f) phase += 1.f;
            }
            w = (w + 1) & MASK;

            // 4. Металл: кольцевая модуляция
            if (metal > 0.f) {
                float rm = y * std::sin(ringPh);
                ringPh += ringInc;
                if (ringPh > 2.f * PI) ringPh -= 2.f * PI;
                y = y * (1.f - metal * 0.7f) + rm * metal;
            }

            // 5. Хрип: мягкое ограничение
            if (drive > 0.f) y = (1.f - drive) * y + drive * std::tanh(k * y) * kNorm;

            // 6. Яркость: ФНЧ (ниже — глуше, меньше свиста)
            lp += lpA * (y - lp);
            y = lp;

            // 7. Громкость и защитный ограничитель
            out[i] = std::tanh(y * gain);
        }
    }

private:
    static constexpr int SIZE = 16384;
    static constexpr int MASK = SIZE - 1;
    float buf[SIZE];
    int w = 0;
    float fs = 48000.f;
    float phase = 0.f, ringPh = 0.f;
    float hpX = 0.f, hpY = 0.f, lp = 0.f, env = 0.f, gateGain = 0.f;

    static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

    float read(float d) const {
        float rp = (float) w - d;
        int i0 = (int) std::floor(rp);
        float f = rp - (float) i0;
        float a = buf[i0 & MASK];
        float b = buf[(i0 + 1) & MASK];
        return a + f * (b - a);
    }
};
