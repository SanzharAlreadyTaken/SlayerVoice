package com.slayer.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val red = Color.parseColor("#D62828")
    private val bg = Color.parseColor("#121212")
    private val panel = Color.parseColor("#1E1E1E")

    private lateinit var toggle: Button
    private lateinit var status: TextView
    private val seekBars = arrayOfNulls<SeekBar>(Params.names.size)
    private val valueLabels = arrayOfNulls<TextView>(Params.names.size)
    private val handler = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        setContentView(buildUi())
        loadSliders()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            text = "SLAYER VOICE"
            setTextColor(red)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.1f
        })

        toggle = Button(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(red, 16)
            setOnClickListener { onToggle() }
        }
        root.addView(toggle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(72)
        ).apply { topMargin = dp(20) })

        status = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(status)

        // Пресеты
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Params.presets.forEach { (name, values) ->
            presetRow.addView(Button(this).apply {
                text = name
                isAllCaps = false
                textSize = 14f
                setTextColor(Color.WHITE)
                background = rounded(panel, 12)
                setOnClickListener { applyPreset(values) }
            }, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginStart = dp(3); marginEnd = dp(3)
            })
        }
        root.addView(presetRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8); bottomMargin = dp(12) })

        // Ползунки
        Params.names.forEachIndexed { id, name ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(panel, 12)
                setPadding(dp(14), dp(10), dp(14), dp(6))
            }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            header.addView(TextView(this).apply {
                text = name
                setTextColor(Color.WHITE)
                textSize = 16f
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val label = TextView(this).apply {
                setTextColor(red)
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
            }
            valueLabels[id] = label
            header.addView(label)
            box.addView(header)

            val sb = SeekBar(this).apply {
                max = 100
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                        setLabel(id, v)
                        Params.apply(id, v)
                        if (fromUser) Params.save(this@MainActivity, id, v)
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            }
            seekBars[id] = sb
            box.addView(sb)
            root.addView(box, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) })
        }

        root.addView(TextView(this).apply {
            text = "Колонку подключай проводом (AUX) — Bluetooth добавляет задержку 0,2–0,3 с.\n" +
                    "Свистит — убавь громкость, «Яркость» или прибавь «Шумодав», " +
                    "и отодвинь колонку от микрофона."
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        }
    }

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun setLabel(id: Int, v: Int) {
        valueLabels[id]?.text = if (id == Params.PITCH) {
            "×%.2f".format(Params.toValue(id, v))
        } else "$v%"
    }

    private fun loadSliders() {
        Params.load(this).forEachIndexed { id, v ->
            seekBars[id]?.progress = v
            setLabel(id, v)
            Params.apply(id, v)
        }
    }

    private fun applyPreset(values: IntArray) {
        values.forEachIndexed { id, v ->
            seekBars[id]?.progress = v
            Params.save(this, id, v)
        }
    }

    private fun updateStatus() {
        val on = VoiceService.running
        toggle.text = if (on) "ВЫКЛЮЧИТЬ" else "ВКЛЮЧИТЬ"
        toggle.background = rounded(if (on) Color.parseColor("#444444") else red, 16)
        status.text = when {
            on -> NativeEngine.info()
            VoiceService.error != null -> VoiceService.error
            else -> "Выключено"
        }
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- Запуск ----------

    private fun onToggle() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java))
            handler.postDelayed({ updateStatus() }, 200)
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startVoice() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else {
            Toast.makeText(this, "Без доступа к микрофону не получится", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVoice() {
        VoiceService.error = null
        startForegroundService(Intent(this, VoiceService::class.java))
        handler.postDelayed({ updateStatus() }, 300)
    }
}
