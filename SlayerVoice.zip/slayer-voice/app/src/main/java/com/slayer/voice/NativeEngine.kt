package com.slayer.voice

import android.content.Context

/** Мост к C++ движку. */
object NativeEngine {
    init {
        System.loadLibrary("slayervoice")
    }

    external fun start(): Boolean
    external fun stop()
    external fun setParam(id: Int, value: Float)
    external fun info(): String
}

/** Параметры: хранятся как положения ползунков 0..100. */
object Params {
    const val PITCH = 0
    const val METAL = 1
    const val DRIVE = 2
    const val TONE = 3
    const val GATE = 4
    const val VOLUME = 5

    val names = arrayOf("Высота голоса", "Металл", "Хрип", "Яркость", "Шумодав", "Громкость")
    val defaults = intArrayOf(28, 15, 25, 60, 30, 60)

    /** Пресеты: значения для первых пяти ползунков (громкость не трогаем). */
    val presets = linkedMapOf(
        "Слейер" to intArrayOf(28, 15, 25, 60, 30),
        "Демон" to intArrayOf(12, 30, 45, 45, 35),
        "Робот" to intArrayOf(50, 80, 10, 70, 30),
        "Чистый" to intArrayOf(50, 0, 0, 100, 20),
    )

    private const val PREFS = "params"

    fun toValue(id: Int, slider: Int): Float =
        if (id == PITCH) 0.5f + slider / 100f else slider / 100f

    fun load(ctx: Context): IntArray {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return IntArray(names.size) { p.getInt("p$it", defaults[it]) }
    }

    fun save(ctx: Context, id: Int, slider: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("p$id", slider).apply()
    }

    fun apply(id: Int, slider: Int) = NativeEngine.setParam(id, toValue(id, slider))

    fun applyAll(ctx: Context) {
        load(ctx).forEachIndexed { id, v -> apply(id, v) }
    }
}
