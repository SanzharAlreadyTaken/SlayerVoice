// Slayer Voice — обработка голоса в реальном времени.
// Цепочка: срез низа 80 Гц -> шумодав -> понижение голоса -> бас -> чёткость ->
//          «металл» -> хрип -> яркость -> громкость.
#pragma once
#include <atomic>
#include <cmath>
#include <cstring>

enum Param {
    P_PITCH = 0,   // коэффициент высоты 0.5..1.5
    P_METAL,       // 0..1
    P_DRIVE,       // 0..1
    P_TONE,        // 0..1  яркость (ФНЧ 1..10 кГц)
    P_GATE,        // 0..1  шумодав
    P_VOLUME,      // 0..1
    P_CLARITY,     // 0..1  подъём 3 кГц (разборчивость) 0..+10 дБ
    P_BASS,        // 0..1  подъём низа 160 Гц 0..+9 дБ
    P_FAST,        // 0..1  быстрая речь: окно сдвига 60 -> 15 мс
    P_BUFFER,      // 0..1  запас буфера (используется движком, не DSP)
    P_COUNT
};

// Биквад (формулы RBJ)
struct Biquad {
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1 = 0, z2 = 0;

    void reset() { z1 = z2 = 0; }

    inline float process(float x) {
        float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void peaking(float fs, float f0, float q, float dB) {
        const float A = std::pow(10.f, dB / 40.f);
        const float w = 2.f * 3.14159265f * f0 / fs;
        const float al = std::sin(w) / (2.f * q);
        const float c = std::cos(w);
        const float a0 = 1.f + al / A;
        b0 = (1.f + al * A) / a0;
        b1 = (-2.f * c) / a0;
        b2 = (1.f - al * A) / a0;
        a1 = (-2.f * c) / a0;
        a2 = (1.f - al / A) / a0;
    }

    void lowShelf(float fs, float f0, float dB) {
        const float A = std::pow(10.f, dB / 40.f);
        const float w = 2.f * 3.14159265f * f0 / fs;
        const float c = std::cos(w);
        const float s = std::sin(w);
        const float al = s / 2.f * std::sqrt(2.f);   // наклон S = 1
        const float sq = 2.f * std::sqrt(A) * al;
        const float a0 = (A + 1) + (A - 1) * c + sq;
        b0 = A * ((A + 1) - (A - 1) * c + sq) / a0;
        b1 = 2 * A * ((A - 1) - (A + 1) * c) / a0;
        b2 = A * ((A + 1) - (A - 1) * c - sq) / a0;
        a1 = -2 * ((A - 1) + (A + 1) * c) / a0;
        a2 = ((A + 1) + (A - 1) * c - sq) / a0;
    }
};

class VoiceDSP {
public:
    std::atomic<float> params[P_COUNT];

    VoiceDSP() {
        params[P_PITCH] = 0.78f;
        params[P_METAL] = 0.15f;
        params[P_DRIVE] = 0.25f;
        params[P_TONE] = 0.60f;
        params[P_GATE] = 0.30f;
        params[P_VOLUME] = 0.60f;
        params[P_CLARITY] = 0.50f;
        params[P_BASS] = 0.40f;
        params[P_FAST] = 0.40f;
        params[P_BUFFER] = 0.50f;
        reset();
    }

    void setSampleRate(float sr) {
        fs = sr > 8000.f ? sr : 48000.f;
        lastClarity = lastBass = -1.f;
        reset();
    }

    void reset() {
        std::memset(buf, 0, sizeof(buf));
        w = 0;
        phase = 0.f;
        ringPh = 0.f;
        hpX = hpY = 0.f;
        lp = 0.f;
        env = 0.f;
        gateGain = 0.f;
        presence.reset();
        bass.reset();
    }

    void process(const float *in, float *out, int n) {
        const float PI = 3.14159265f;
        const float ratio = clampf(params[P_PITCH].load(), 0.4f, 1.6f);
        const float metal = clampf(params[P_METAL].load(), 0.f, 1.f);
        const float drive = clampf(params[P_DRIVE].load(), 0.f, 1.f);
        const float tone = clampf(params[P_TONE].load(), 0.f, 1.f);
        const float gate = clampf(params[P_GATE].load(), 0.f, 1.f);
        const float vol = clampf(params[P_VOLUME].load(), 0.f, 1.f);
        const float clarity = clampf(params[P_CLARITY].load(), 0.f, 1.f);
        const float bassAmt = clampf(params[P_BASS].load(), 0.f, 1.f);
        const float fast = clampf(params[P_FAST].load(), 0.f, 1.f);

        // Пересчёт фильтров только при изменении ползунков
        if (clarity != lastClarity) { presence.peaking(fs, 3000.f, 0.9f, 10.f * clarity); lastClarity = clarity; }
        if (bassAmt != lastBass) { bass.lowShelf(fs, 160.f, 9.f * bassAmt); lastBass = bassAmt; }

        // Окно сдвига высоты: короче — чётче быстрая речь, длиннее — мягче звук.
        const float W = (0.060f - 0.045f * fast) * fs;
        const float minD = 4.f;
        const float dp = (1.f - ratio) / W;
        const bool bypassPitch = std::fabs(1.f - ratio) < 0.002f;

        const float hpA = 1.f / (1.f + 2.f * PI * 80.f / fs);
        const float thr = std::pow(10.f, (-70.f + 40.f * gate) / 20.f);
        const float envAtt = 1.f - std::exp(-1.f / (0.002f * fs));
        const float envRel = 1.f - std::exp(-1.f / (0.120f * fs));
        const float gOpen = 1.f - std::exp(-1.f / (0.003f * fs));
        const float gClose = 1.f - std::exp(-1.f / (0.080f * fs));
        const float ringInc = 2.f * PI * 70.f / fs;
        const float k = 1.f + drive * 8.f;
        const float kNorm = 1.f / std::sqrt(k);
        const float fc = 1000.f * std::pow(10.f, tone);
        const float lpA = 1.f - std::exp(-2.f * PI * fc / fs);
        const float gain = vol * 4.f;

        for (int i = 0; i < n; ++i) {
            // 1. Срез низа
            float x = in[i];
            hpY = hpA * (hpY + x - hpX);
            hpX = x;
            x = hpY;

            // 2. Шумодав
            float a = std::fabs(x);
            env += (a > env ? envAtt : envRel) * (a - env);
            float target = env > thr ? 1.f : 0.f;
            gateGain += (target > gateGain ? gOpen : gClose) * (target - gateGain);
            x *= gateGain;

            // 3. Сдвиг высоты
            buf[w] = x;
            float y;
            if (bypassPitch) {
                y = x;
            } else {
                if (phase >= 1.f) phase -= 1.f;
                float p2 = phase + 0.5f;
                if (p2 >= 1.f) p2 -= 1.f;
                float y1 = read(minD + phase * W);
                float y2 = read(minD + p2 * W);
                y = y1 * std::sin(PI * phase) + y2 * std::sin(PI * p2);
                phase += dp;
                if (phase >= 1.f) phase -= 1.f;
                if (phase < 0.f) phase += 1.f;
            }
            w = (w + 1) & MASK;

            // 4. Бас и чёткость
            if (bassAmt > 0.f) y = bass.process(y);
            if (clarity > 0.f) y = presence.process(y);

            // 5. Металл
            if (metal > 0.f) {
                float rm = y * std::sin(ringPh);
                ringPh += ringInc;
                if (ringPh > 2.f * PI) ringPh -= 2.f * PI;
                y = y * (1.f - metal * 0.7f) + rm * metal;
            }

            // 6. Хрип
            if (drive > 0.f) y = (1.f - drive) * y + drive * std::tanh(k * y) * kNorm;

            // 7. Яркость
            lp += lpA * (y - lp);
            y = lp;

            // 8. Громкость и ограничитель
            out[i] = std::tanh(y * gain);
        }
    }

private:
    static constexpr int SIZE = 16384;
    static constexpr int MASK = SIZE - 1;
    float buf[SIZE];
    int w = 0;
    float fs = 48000.f;
    float phase = 0.f, ringPh = 0.f;
    float hpX = 0.f, hpY = 0.f, lp = 0.f, env = 0.f, gateGain = 0.f;
    Biquad presence, bass;
    float lastClarity = -1.f, lastBass = -1.f;

    static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

    float read(float d) const {
        float rp = (float) w - d;
        int i0 = (int) std::floor(rp);
        float f = rp - (float) i0;
        float a = buf[i0 & MASK];
        float b = buf[(i0 + 1) & MASK];
        return a + f * (b - a);
    }
};
