// Буфер между микрофоном (свой поток) и выходом (свой поток).
// Один пишет, один читает — без блокировок. Сглаживает неровные пачки Bluetooth
// и не даёт задержке расти.
#pragma once
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <vector>

class AudioFifo {
public:
    explicit AudioFifo(int sizePow2 = 65536) : buf(sizePow2, 0.f), mask((uint64_t) sizePow2 - 1) {}

    // Вызывать только когда оба потока остановлены.
    void clear() {
        rd.store(0); wr.store(0);
        priming = true; extra = 0; calm = 0; underruns.store(0);
    }

    // --- Поток микрофона ---
    void push(const float *src, int n) {
        uint64_t w = wr.load(std::memory_order_relaxed);
        uint64_t r = rd.load(std::memory_order_acquire);
        int freeSpace = (int) (buf.size() - (w - r));
        if (n > freeSpace) n = freeSpace;                       // переполнение — лишнее отбрасываем
        for (int i = 0; i < n; ++i) buf[(w + i) & mask] = src[i];
        wr.store(w + n, std::memory_order_release);
    }

    // --- Поток выхода ---
    // Возвращает false, пока копится запас (выход тогда — тишина).
    bool pop(float *dst, int n, int baseMargin, float blockFactor = 1.f) {
        uint64_t r = rd.load(std::memory_order_relaxed);
        int c = (int) (wr.load(std::memory_order_acquire) - r);
        // Запас: не меньше блока выхода + адаптивная добавка после провалов.
        int margin = std::max(baseMargin, (int) (n * blockFactor)) + extra;
        if (priming) {
            if (c < n + margin) return false;
            priming = false;
        } else if (c < n) {
            priming = true;
            underruns.fetch_add(1, std::memory_order_relaxed);
            extra = std::min(extra + std::max(n / 2, 256), n * 3 + 8192);
            calm = 0;
            return false;
        }
        // Долго без провалов — понемногу уменьшаем добавку.
        if (++calm > 6000 && extra > 0) { extra -= std::min(extra, 16); calm = 0; }
        // Накопилось лишнего (часы входа/выхода разошлись) — догоняем.
        if (c > n * 2 + margin * 2) r += (uint64_t) (c - (n + margin));
        for (int i = 0; i < n; ++i) dst[i] = buf[(r + i) & mask];
        rd.store(r + n, std::memory_order_release);
        return true;
    }

    int level() const { return (int) (wr.load() - rd.load()); }
    int underrunCount() const { return underruns.load(); }

private:
    std::vector<float> buf;
    uint64_t mask;
    std::atomic<uint64_t> rd{0}, wr{0};
    std::atomic<int> underruns{0};
    // Состояние потока выхода
    bool priming = true;
    int extra = 0;
    int calm = 0;
};
