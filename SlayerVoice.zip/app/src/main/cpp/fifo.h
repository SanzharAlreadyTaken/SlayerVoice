// Буфер между микрофоном и выходом: сглаживает неровные пачки (Bluetooth),
// но не даёт задержке расти.
#pragma once
#include <cstdint>
#include <vector>
#include <algorithm>

class AudioFifo {
public:
    explicit AudioFifo(int sizePow2 = 65536) : buf(sizePow2, 0.f), mask(sizePow2 - 1) {}

    void clear() { rd = wr = 0; priming = true; extra = 0; }

    int count() const { return (int) (wr - rd); }

    void push(const float *src, int n) {
        for (int i = 0; i < n; ++i) buf[(wr++) & mask] = src[i];
        int over = count() - (int) buf.size();
        if (over > 0) rd += over;
    }

    // Выдать n сэмплов. margin — запас, который держим в буфере сверх n.
    // Возвращает false, если пока копим (выход тогда — тишина).
    bool pop(float *dst, int n, int baseMargin) {
        // Запас: не меньше половины блока выхода (Bluetooth берёт крупно и неровно)
        // + адаптивная добавка, которая растёт после провалов и медленно спадает.
        int margin = std::max(baseMargin, n / 2) + extra;
        int c = count();
        if (priming) {
            if (c < n + margin) return false;
            priming = false;
        } else if (c < n) {
            priming = true;                                  // провал: копим заново
            extra = std::min(extra + std::max(n / 4, 64), n * 2 + 4096);
            calm = 0;
            return false;
        }
        if (++calm > 3000 && extra > 0) { extra -= std::min(extra, 16); calm = 0; }
        // Накопилось лишнего больше целого блока (часы разошлись) — догоняем.
        if (c > n * 2 + margin) rd += (uint64_t) (c - (n + margin));
        for (int i = 0; i < n; ++i) dst[i] = buf[(rd++) & mask];
        return true;
    }

    int extraMargin() const { return extra; }

private:
    std::vector<float> buf;
    uint64_t mask;
    uint64_t rd = 0, wr = 0;
    bool priming = true;
    int extra = 0;
    int calm = 0;
};
