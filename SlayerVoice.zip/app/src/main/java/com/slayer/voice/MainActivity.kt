package com.slayer.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val red = Color.parseColor("#D62828")
    private val bg = Color.parseColor("#121212")
    private val panel = Color.parseColor("#1E1E1E")
    private val idle = Color.parseColor("#2C2C2C")

    private lateinit var toggle: Button
    private lateinit var status: TextView
    private lateinit var presetTitle: TextView
    private val presetButtons = mutableMapOf<String, Button>()
    private val seekBars = arrayOfNulls<SeekBar>(Params.COUNT)
    private val valueLabels = arrayOfNulls<TextView>(Params.COUNT)
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var preset: String
    private var loading = false   // чтобы при загрузке значений ничего не перезаписывалось

    private val poll = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        preset = Params.currentPreset(this)
        setContentView(buildUi())
        loadAll()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(Color.GRAY)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
        setPadding(dp(4), dp(14), 0, dp(6))
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            text = "SLAYER VOICE"
            setTextColor(red)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.1f
        })

        toggle = Button(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(red, 16)
            setOnClickListener { onToggle() }
        }
        root.addView(toggle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(72)
        ).apply { topMargin = dp(20) })

        status = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(status)

        // Пресеты
        root.addView(sectionTitle("ПРЕСЕТ"))
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Params.presetNames.forEach { name ->
            val b = Button(this).apply {
                text = name
                isAllCaps = false
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                setOnClickListener { selectPreset(name) }
            }
            presetButtons[name] = b
            presetRow.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                marginStart = dp(4); marginEnd = dp(4)
            })
        }
        root.addView(presetRow)

        presetTitle = TextView(this).apply {
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(dp(4), dp(6), 0, dp(4))
        }
        root.addView(presetTitle)

        Params.presetSliders.forEach { root.addView(sliderBox(it)) }

        root.addView(Button(this).apply {
            text = "Сбросить пресет к заводским"
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.LTGRAY)
            background = rounded(idle, 12)
            setOnClickListener {
                Params.resetPreset(this@MainActivity, preset)
                loadAll()
                Toast.makeText(this@MainActivity, "«$preset» сброшен", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply {
            topMargin = dp(2)
        })

        root.addView(sectionTitle("ОБЩИЕ"))
        Params.globalSliders.forEach { root.addView(sliderBox(it)) }

        root.addView(TextView(this).apply {
            text = "Каждый пресет запоминает свои настройки.\n" +
                    "Bluetooth-колонка сама даёт ~0,2 с задержки — это её кодек, " +
                    "по проводу задержка в разы меньше.\n" +
                    "Свистит — убавь громкость или «Яркость», прибавь «Шумодав», " +
                    "отодвинь колонку от микрофона."
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })

        return ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        }
    }

    private fun sliderBox(def: SliderDef): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 12)
            setPadding(dp(14), dp(10), dp(14), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = def.name
            setTextColor(Color.WHITE)
            textSize = 16f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val label = TextView(this).apply {
            setTextColor(red)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        valueLabels[def.id] = label
        header.addView(label)
        box.addView(header)

        def.hint?.let {
            box.addView(TextView(this).apply {
                text = it
                setTextColor(Color.GRAY)
                textSize = 12f
            })
        }

        val sb = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                    setLabel(def.id, v)
                    Params.apply(def.id, v)
                    if (!loading && fromUser) {
                        if (def.global) Params.saveGlobalValue(this@MainActivity, def.id, v)
                        else Params.savePresetValue(this@MainActivity, preset, def.id, v)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        seekBars[def.id] = sb
        box.addView(sb)
        return box
    }

    private fun setLabel(id: Int, v: Int) {
        valueLabels[id]?.text = if (id == Params.PITCH) {
            "×%.2f".format(Params.toValue(id, v))
        } else "$v%"
    }

    private fun loadAll() {
        loading = true
        Params.presetSliders.forEach { setSlider(it.id, Params.presetValue(this, preset, it.id)) }
        Params.globalSliders.forEach { setSlider(it.id, Params.globalValue(this, it.id)) }
        loading = false
        presetButtons.forEach { (name, b) -> b.background = rounded(if (name == preset) red else idle, 12) }
        presetTitle.text = "Настройки пресета «$preset» — сохраняются автоматически"
    }

    private fun setSlider(id: Int, v: Int) {
        seekBars[id]?.progress = v
        setLabel(id, v)
        Params.apply(id, v)
    }

    private fun selectPreset(name: String) {
        preset = name
        Params.setCurrentPreset(this, name)
        loadAll()
    }

    private fun updateStatus() {
        val on = VoiceService.running
        toggle.text = if (on) "ВЫКЛЮЧИТЬ" else "ВКЛЮЧИТЬ"
        toggle.background = rounded(if (on) Color.parseColor("#444444") else red, 16)
        status.text = when {
            on -> NativeEngine.info()
            VoiceService.error != null -> VoiceService.error
            else -> "Выключено"
        }
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- Запуск ----------

    private fun onToggle() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java))
            handler.postDelayed({ updateStatus() }, 200)
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startVoice() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else {
            Toast.makeText(this, "Без доступа к микрофону не получится", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVoice() {
        VoiceService.error = null
        startForegroundService(Intent(this, VoiceService::class.java))
        handler.postDelayed({ updateStatus() }, 300)
    }
}
