package com.slayer.voice

import android.content.Context

/** Мост к C++ движку. */
object NativeEngine {
    init {
        System.loadLibrary("slayervoice")
    }

    external fun start(): Boolean
    external fun stop()
    external fun setParam(id: Int, value: Float)
    external fun info(): String
}

/** Описание ползунка. global = общий для всех пресетов. */
class SliderDef(val id: Int, val name: String, val hint: String? = null, val global: Boolean = false)

/** Параметры и пресеты. Значения ползунков 0..100. */
object Params {
    // id совпадают с enum Param в dsp.h
    const val PITCH = 0
    const val METAL = 1
    const val DRIVE = 2
    const val TONE = 3
    const val GATE = 4
    const val VOLUME = 5
    const val CLARITY = 6
    const val BASS = 7
    const val FAST = 8
    const val BUFFER = 9
    const val COUNT = 10

    val presetSliders = listOf(
        SliderDef(PITCH, "Высота голоса"),
        SliderDef(BASS, "Бас", "Мощь и глубина голоса"),
        SliderDef(FAST, "Быстрая речь", "Выше — чётче согласные, если говоришь быстро"),
        SliderDef(CLARITY, "Чёткость", "Подчёркивает частоты, от которых зависит разборчивость"),
        SliderDef(METAL, "Металл"),
        SliderDef(DRIVE, "Хрип"),
        SliderDef(TONE, "Яркость", "Ниже — глуше и меньше свиста"),
        SliderDef(GATE, "Шумодав", "Если обрезает тихие слова — убавь"),
    )

    val globalSliders = listOf(
        SliderDef(VOLUME, "Громкость", global = true),
        SliderDef(
            BUFFER, "Запас буфера",
            "Меньше — меньше задержка. Если «провалов звука» становится больше — прибавь.",
            global = true
        ),
    )

    val presetNames = listOf("Слейер", "Чистый")

    private val presetDefaults = mapOf(
        "Слейер" to mapOf(PITCH to 28, BASS to 40, FAST to 40, CLARITY to 50, METAL to 15, DRIVE to 25, TONE to 60, GATE to 30),
        "Чистый" to mapOf(PITCH to 50, BASS to 0, FAST to 50, CLARITY to 30, METAL to 0, DRIVE to 0, TONE to 100, GATE to 20),
    )
    private val globalDefaults = mapOf(VOLUME to 60, BUFFER to 50)

    private const val PREFS = "params2"

    fun toValue(id: Int, slider: Int): Float =
        if (id == PITCH) 0.5f + slider / 100f else slider / 100f

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun currentPreset(ctx: Context): String =
        prefs(ctx).getString("preset", presetNames[0]).takeIf { it in presetNames } ?: presetNames[0]

    fun setCurrentPreset(ctx: Context, name: String) =
        prefs(ctx).edit().putString("preset", name).apply()

    fun presetValue(ctx: Context, preset: String, id: Int): Int =
        prefs(ctx).getInt("$preset/$id", presetDefaults.getValue(preset).getValue(id))

    fun savePresetValue(ctx: Context, preset: String, id: Int, v: Int) =
        prefs(ctx).edit().putInt("$preset/$id", v).apply()

    fun resetPreset(ctx: Context, preset: String) {
        val e = prefs(ctx).edit()
        presetDefaults.getValue(preset).keys.forEach { e.remove("$preset/$it") }
        e.apply()
    }

    fun globalValue(ctx: Context, id: Int): Int = prefs(ctx).getInt("g/$id", globalDefaults.getValue(id))

    fun saveGlobalValue(ctx: Context, id: Int, v: Int) = prefs(ctx).edit().putInt("g/$id", v).apply()

    fun apply(id: Int, slider: Int) = NativeEngine.setParam(id, toValue(id, slider))

    /** Применить текущий пресет и общие настройки к движку. */
    fun applyAll(ctx: Context) {
        val p = currentPreset(ctx)
        presetSliders.forEach { apply(it.id, presetValue(ctx, p, it.id)) }
        globalSliders.forEach { apply(it.id, globalValue(ctx, it.id)) }
    }
}
